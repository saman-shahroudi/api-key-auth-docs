#!/bin/bash
echo "========================================"
echo "Fedshi Integration Tool"
echo "========================================"
echo
echo "Starting the server..."
echo
./FedshiIntegrationTool
echo
echo "Press Enter to exit..."
read
